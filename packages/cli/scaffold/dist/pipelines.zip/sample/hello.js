// rendered with love by YogaBot

const blocks = require("@datayoga-io/dy-js-runner/dist/common/blocks");
const { DyQuery } = require("@datayoga-io/dy-js-runner");
let logger = console;

async function run(runner,args={},options={}) {
        
    let df_extract_sample_csv = blocks.extract(
        runner,
        logger,
        {
      "source": "sample_raw_input",
      "type": "file"
    },
        {  }
    )
    
    
    blocks.load(
        runner,
        logger,
        {
      "target_type": "stdout"
    },
        { 
            "df":"",
         }
    )
}
exports.run=run